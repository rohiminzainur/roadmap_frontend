#!/bin/bash

clj -A:nrepl -M -m nrepl.cmdline --interactive