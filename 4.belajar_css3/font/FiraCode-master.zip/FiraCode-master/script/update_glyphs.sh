#!/bin/zsh -euo pipefail

clojure -M -m fira-code.main